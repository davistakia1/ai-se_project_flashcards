import { decks, getDeckByID } from "./decks.js";
import { hexToString } from "./colors.js";
import { renderCarouselView } from "./carousel.js";
import { renderDeckView } from "./deck-view.js";

const page = document.querySelector(".page");
const mobileBar = document.querySelector(".mobile-bar");

const homeSection = document.querySelector("#home");
const notFoundSection = document.querySelector("#not-found");
const carouselSection = document.querySelector(".carousel");

const deckSection = document.querySelector("#deck-view");
const deckPracticeButton = document.querySelector(
  "#deck-view .gallery__practice-btn",
);

const mainContent = document.querySelector(".page__main-content");
const deckTemplate = document.querySelector("#deck-template");
const deckList = document.querySelector(".gallery__list");

function createDeckEl(item) {
  const deckElement = deckTemplate.content
    .querySelector(".card")
    .cloneNode(true);

  const deckLink = deckElement.querySelector(".card__link");
  deckLink.href = `#deck/${item.id}`;
  // Set the deck title

  deckElement.querySelector(".card__title").textContent = item.name;

  // Set the card count
  deckElement.querySelector(".card__count").textContent =
    `${item.cards.length} cards`;

  // Set the deck color
  const colorName = hexToString(item.color);

  deckElement.classList.remove("card_color_green");
  deckElement.classList.add(`card_color_${colorName}`);

  // Delete button
  const deleteBtn = deckElement.querySelector(".card__btn_type_delete");

  deleteBtn.addEventListener("click", () => {
    deckElement.remove();
  });

  return deckElement;
}

function renderDeckEl(item) {
  const deckElement = createDeckEl(item);

  deckList.prepend(deckElement);
}
function showView(currentSection, display) {
  homeSection.style.display = "none";
  notFoundSection.style.display = "none";
  carouselSection.style.display = "none";
  deckSection.style.display = "none";

  currentSection.style.display = display;
}

function renderCurrentView() {
  const hash = window.location.hash || "#home";

  mobileBar.style.display = hash === "#home" ? "" : "none";

  if (hash === "#home") {
    showView(homeSection, "block");
    mainContent.classList.remove("page__main-content_location_carousel");
    page.classList.remove("page_no-mobile-bar");
  } else if (hash.startsWith("#carousel/")) {
    const currentDeckID = hash.split("/")[1];
    const currentDeck = getDeckByID(currentDeckID);

    renderCarouselView(currentDeck);

    showView(carouselSection, "flex");
    mainContent.classList.add("page__main-content_location_carousel");
    page.classList.add("page_no-mobile-bar");
  } else if (hash.startsWith("#deck/")) {
    const currentDeckID = hash.split("/")[1];
    const currentDeck = getDeckByID(currentDeckID);

    renderDeckView(currentDeck);
    page.classList.remove("page_no-mobile-bar");

    deckPracticeButton.onclick = () => {
      window.location.hash = `#carousel/${currentDeck.id}`;
    };

    showView(deckSection, "block");
  } else {
    showView(notFoundSection, "flex");
    mainContent.classList.remove("page__main-content_location_carousel");
    page.classList.add("page_no-mobile-bar");
  }
}

decks.forEach(renderDeckEl);

window.addEventListener("hashchange", renderCurrentView);

renderCurrentView();
